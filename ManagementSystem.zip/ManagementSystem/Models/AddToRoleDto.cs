﻿namespace ManagementSystem.Models
{
    public class AddToRoleDto
    {
        public string UserId { get; set; }
        public string Role { get; set; }
    }
}
