﻿using Microsoft.AspNetCore.Identity;

namespace ManagementSystem.Models
{
    public class DbUser : IdentityUser<string>
    {
    }
}
