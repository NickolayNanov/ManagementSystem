﻿using Microsoft.AspNetCore.Identity;

namespace ManagementSystem.Models
{
    public class DbRole : IdentityRole<string>
    {
    }
}
