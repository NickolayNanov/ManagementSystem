﻿namespace ManagementSystem.Models
{
    public class LoginCredsDto
    {
        public string Email { get; set; }

        public string Password { get; set; }
    }
}
